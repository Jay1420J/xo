from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, PasswordChangeForm, AuthenticationForm
from .models import UserFaceImage
from .utils import base64_file


class UserCreationForm(UserCreationForm):
    image = forms.CharField(widget=forms.HiddenInput())

    class Meta:
        model = User
        fields = ("first_name", "email", "username", "password1", "password2")

    def save(self, commit=True):
        if not commit:
            raise NotImplementedError("Can't create User and UserFaceImage without database save")
        user = super(UserCreationForm, self).save(commit=True)
        image = base64_file(self.data['image'])
        face_image = UserFaceImage(user=user, image=image)
        face_image.save()
        return user
    
class UserCreationFormFile(UserCreationForm):
    image = forms.CharField(widget=forms.HiddenInput())

    class Meta:
        model = User
        fields = ("first_name", "email", "username", "password1", "password2")

    def save(self, commit=True):
        if not commit:
            raise NotImplementedError("Can't create User and UserFaceImage without database save")
        user = super(UserCreationForm, self).save(commit=True)
        image = self.data['image']
        face_image = UserFaceImage(user=user, image=image)
        face_image.save()
        return user

class AuthenticationForm(AuthenticationForm):
    image = forms.CharField(widget=forms.HiddenInput())


class UserChangeForm(UserChangeForm):
    # image = forms.CharField(widget=forms.HiddenInput())

    class Meta:
        model = User
        fields = ("first_name", "email", "username", "password")

    def save(self, commit=True):
        if not commit:
            raise NotImplementedError("Can't Update User")
        user = super(UserChangeForm, self).save(commit=True)
        return user

class PasswordChangeForm(PasswordChangeForm):
    # image = forms.CharField(widget=forms.HiddenInput())

    class Meta:
        model = User
        fields = ("old_password", "new_password1", "new_password2")

    def save(self, commit=True):
        if not commit:
            raise NotImplementedError("Can't create change password")
        user = super(PasswordChangeForm, self).save(commit=True)
        return user