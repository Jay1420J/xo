from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.conf import settings
from .forms import UserCreationForm, UserCreationFormFile, UserChangeForm, PasswordChangeForm, AuthenticationForm
from .authenticate import FaceIdAuthBackend
from .utils import prepare_image
from .models import UserFaceImage
from post.models import Post

def register(request):
    if  request.method == 'POST':
        form = UserCreationForm(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password2']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect(settings.LOGIN_REDIRECT_URL)
    else:
        form = UserCreationForm()

    context = {'form': form}
    return render(request, 'register.html', context)

def register_from_file(request):
    if  request.method == 'POST':
        form = UserCreationFormFile(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password2']
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect(settings.LOGIN_REDIRECT_URL)
    else:
        form = UserCreationFormFile()

    context = {'form': form}
    return render(request, 'register_with_file.html', context)

def face_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)

        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            # face_image = prepare_image(form.cleaned_data['image'])

            # face_id = FaceIdAuthBackend()
            # user = face_id.authenticate(username=username, password=password, face_id=face_image)
            # if user is not None:
            #     login(request, user)
            #     return redirect(settings.LOGIN_REDIRECT_URL)
            # else:
            #     form.add_error(None, "Username, password or face id didn't match.")

            user = User.objects.get(username=username)
            if user.check_password(password):
                login(request, user)
                return redirect(settings.LOGIN_REDIRECT_URL)
    else:
        form = AuthenticationForm()

    context = {'form': form}
    return render(request, 'login.html', context)

def profile(request):
    try:
        user = request.user
        user_image = UserFaceImage.objects.filter(user=user).first()
        context = {'user': user, 'image': user_image.image}
        return render(request, 'index-2.html', context)
    except:
        return redirect('/user/accounts/login/')

def edit_profile(request):
    try:
        user = request.user
        user_image = UserFaceImage.objects.filter(user=user).first()
        if  request.method == 'POST':
            form = UserChangeForm(instance=user, data=request.POST)
            password_change_form = PasswordChangeForm(user=user)

            if form.is_valid():
                form.save()
                return redirect('/user/accounts/editprofile/')
        else:
            form = UserChangeForm(instance=user)
            password_change_form = PasswordChangeForm(user=user)

        posts = Post.objects.filter(user=user)
        context = {'form': form, 'image': user_image.image, 'password_change_form': password_change_form, 'posts': posts}
        return render(request, 'edit_profile.html', context)
    except:
        return redirect('/user/accounts/login/')

def update_password(request):
    try:
        user = request.user
        user_image = UserFaceImage.objects.filter(user=user).first()
        if  request.method == 'POST':
            form = UserChangeForm(instance=user)
            password_change_form = PasswordChangeForm(user=user, data=request.POST)

            if password_change_form.is_valid():
                password_change_form.save()
                return redirect('/user/accounts/editprofile/')
            
        else:
            form = UserChangeForm(instance=user)
            password_change_form = PasswordChangeForm(user=user)

        posts = Post.objects.filter(user=user)
        context = {'form': form, 'image': user_image.image, 'password_change_form': password_change_form, 'posts': posts}
        return render(request, 'edit_profile.html', context)
    except:
        return redirect('/user/accounts/login/')
    
def blogpost(request):
    try:
        user = request.user
        user_image = UserFaceImage.objects.filter(user=user).first()
        context = {'user': user, 'image': user_image.image}
        return render(request, 'blog-single.html', context)
    except:
        return render(request, 'blog-single.html')
