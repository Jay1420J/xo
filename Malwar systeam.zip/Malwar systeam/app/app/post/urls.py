from django.urls import path
from django.conf.urls import handler500

handler500 = 'urlscanner.views.error_500'
handler404 = 'urlscanner.views.error_404'


from . import views





urlpatterns = [
    path('add/', views.add, name='add_new_post'),
    path('<int:pk>/', views.detail, name='post_detail'),
]
