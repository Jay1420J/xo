from django.contrib.auth.models import User
from django.db import models
import time
import os

def post_file_name(instance, filename):
    timestr = time.strftime("%Y%m%d-%H%M%S")
    name, extension = os.path.splitext(filename)
    return os.path.join('content', 'post', timestr + extension)

class Post(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    heading = models.TextField(null=False, blank=False)
    body =models.TextField(null=False, blank=False)
    tags = models.TextField(null=False, blank=False)
    image = models.ImageField(upload_to=post_file_name, blank=False)

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    content = models.TextField(null=False, blank=False)
    name = models.CharField(max_length=100, null=False, blank=False)
    email = models.CharField(max_length=100, null=False, blank=False)