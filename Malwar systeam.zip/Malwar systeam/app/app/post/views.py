from django.shortcuts import render
from .forms import PostForm, CommentForm
from .models import Post, Comment
from custom_auth.models import UserFaceImage

def add(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
    else:
        form = PostForm()
    user = request.user
    user_image = UserFaceImage.objects.filter(user=user).first()
    context = {'user': user, 'image': user_image.image, 'form': form}
    return render(request, 'add_new_post.html', context)


def detail(request, pk):
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            form.save()
    else:
        form = CommentForm()
    post = Post.objects.get(pk=pk)
    comments = Comment.objects.filter(post=post)
    context = {'post': post, 'form': form, 'comments': comments}
    try:
        user = request.user
        user_image = UserFaceImage.objects.filter(user=user).first()
        context['user'] = user
        context['image'] = user_image.image
    except:
        pass

    return render(request, 'blog-single.html',context)