from django.shortcuts import render
from django.http import HttpResponse
from .forms import MalUrlForm
import urllib.request as urllib
import os
import re
import json
from django.core.validators import URLValidator
from django.core.exceptions import ValidationError

# apikey =  os.environ.get('API_KEY')
apikey = "f65da5c7630dbf6993c89bad0d9219cb49c770e23da78ad8d688725d2922d0a5"

def error_500(request,exception=None):
    return render(request, "urlerror.html", {})
    
def error_404(request,exception=None):
    return render(request, "urlerror.html", {})

        

def is_valid_url(url):
    validate = URLValidator()
    try:
        validate(url)
        return True
    except ValidationError:
        return False 


def malurl_form(request):
    if request.method == 'POST':
        form = MalUrlForm(request.POST)

        if form.is_valid():
            geturl = request.POST.get("url", "")
            if is_valid_url(geturl)==False:
               return render(request, 'scanurl.html', {'result': "The url you provided is either incorrect or is not an alive domain"})
            cmd = "curl --request GET --url \"https://www.virustotal.com/vtapi/v2/url/report?apikey="+apikey+"&resource="+geturl+"\""
            # cmd = "curl -s --request GET --url 'https://www.virustotal.com/vtapi/v2/url/report?apikey="+apikey+"&resource="+geturl+"'"
            print(cmd)
            resp = os.popen(cmd)
            output = resp.read()
            try:
                imprint = json.loads(output)['positives']
                total = json.loads(output)['total']
            except:
                return render(request, 'scanurl.html', {'result': "The url you provided is either incorrect or is not an alive domain"})
            print("imprint: ", imprint)
            print("total: ", total)
            if imprint/total>=0.1:
               result="The site is malicious, "+str(imprint)+" of our databases, out of " + str(total) + " has marked it as malicious"
            elif imprint/total>=0.05:
               result="The site may be malicious, "+str(imprint)+ " of our databases, out of " + str(total) + " has marked it as malicious"
            else:
               result="The site seems to be safe according to our databases"
            return render(request, 'scanurl.html', {'result': result})
    else:
        form = MalUrlForm()
    return render(request, 'scanurl.html', {'form': form})
