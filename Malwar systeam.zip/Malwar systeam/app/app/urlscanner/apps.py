from django.apps import AppConfig


class URLScannerConfig(AppConfig):
    name = 'urlscanner'
